/* ================= Link behaviour helpers ================= */

export const LINK_BLOCKED_EVENT = "zoha:link-blocked";

/** True when the page is running inside an iframe (e.g. a preview panel). */
export function isInIframe(): boolean {
  if (typeof window === "undefined") return false;
  try {
    return window.self !== window.top;
  } catch {
    // Cross-origin access throws — that means we ARE framed.
    return true;
  }
}

/** True for external links (http/https). */
export function isExternal(href: string): boolean {
  return /^https?:\/\//i.test(href);
}

/**
 * Target for external links such as
 *  - WhatsApp: https://wa.me/96565592330
 *  - LinkedIn: https://www.linkedin.com/in/zohasheikhsales
 *
 * Inside an iframe we use "_top" so the link escapes the preview frame;
 * otherwise "_blank" for a normal new tab.
 */
export function getLinkTarget(href: string): string | undefined {
  if (!isExternal(href)) return undefined;
  return isInIframe() ? "_top" : "_blank";
}

/**
 * Try hard to open an external URL:
 *   1. new tab (normal browsers)
 *   2. break out of the iframe (preview panels)
 * If both are blocked, emit an event so the UI can show a manual fallback
 * instead of the click appearing to do nothing.
 */
export function openExternal(url: string): boolean {
  // 1. Normal new tab.
  try {
    const win = window.open(url, "_blank", "noopener,noreferrer");
    if (win) {
      try {
        win.opener = null;
      } catch {
        /* ignore */
      }
      return true;
    }
  } catch {
    /* popup blocked — fall through */
  }

  // 2. Escape the iframe.
  try {
    if (window.top && window.top !== window.self) {
      window.top.location.href = url;
      return true;
    }
  } catch {
    /* top-navigation blocked by sandbox — fall through */
  }

  // 3. Nothing worked: let the app show the number manually.
  window.dispatchEvent(new CustomEvent(LINK_BLOCKED_EVENT, { detail: { url } }));
  return false;
}

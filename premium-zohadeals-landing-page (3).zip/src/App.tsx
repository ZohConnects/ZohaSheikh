import { useEffect } from "react";
import { isExternal, openExternal } from "./utils/links";
import LinkFallback from "./components/LinkFallback";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Features from "./components/Features";
import Showcase from "./components/Showcase";
import { Benefits, Testimonials } from "./components/Results";
import { Faq, Pricing } from "./components/Pricing";
import { FinalCta, Footer } from "./components/Closing";
import { About, Community, SocialPilot } from "./components/Personal";
import FloatingWhatsApp from "./components/FloatingWhatsApp";

export default function App() {
  useEffect(() => {
    const onClick = (event: MouseEvent) => {
      // Respect modified clicks (open in new tab/window, middle-click).
      if (event.defaultPrevented || event.button !== 0) return;
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;

      const anchor = (event.target as HTMLElement | null)?.closest("a[href]") as
        | HTMLAnchorElement
        | null;
      const href = anchor?.getAttribute("href");
      if (!href || !isExternal(href)) return;

      event.preventDefault();
      openExternal(href);
    };

    document.addEventListener("click", onClick);
    return () => document.removeEventListener("click", onClick);
  }, []);

  return (
    <div className="relative min-h-screen overflow-x-clip bg-ink-950 text-cream">
      {/* skip link */}
      <a
        href="#main"
        className="sr-only z-[80] rounded-full bg-volt-400 px-5 py-2.5 font-display text-sm font-bold text-ink-950 focus:not-sr-only focus:fixed focus:left-4 focus:top-4"
      >
        Skip to content
      </a>

      {/* ambient texture */}
      <div aria-hidden="true" className="noise-layer" />

      <Navbar />

      <main id="main">
        <Hero />
        <About />
        <Features />
        <Showcase />
        <Community />
        <SocialPilot />
        <Benefits />
        <Testimonials />
        <Pricing />
        <Faq />
        <FinalCta />
      </main>

      <Footer />
      <FloatingWhatsApp />
      <LinkFallback />
    </div>
  );
}

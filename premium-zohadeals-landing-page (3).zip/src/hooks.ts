import { useCallback, useEffect, useRef, useState } from "react";

/* ---------- prefers-reduced-motion ---------- */
export function useReducedMotion(): boolean {
  const [reduced, setReduced] = useState(
    () =>
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
  );
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onChange = () => setReduced(mq.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);
  return reduced;
}

/* ---------- in-view (once) ---------- */
export function useInView<T extends HTMLElement = HTMLDivElement>(
  options: { threshold?: number; rootMargin?: string; once?: boolean } = {}
) {
  const { threshold = 0.18, rootMargin = "0px 0px -8% 0px", once = true } = options;
  const ref = useRef<T | null>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setInView(true);
            if (once) io.unobserve(entry.target);
          } else if (!once) {
            setInView(false);
          }
        });
      },
      { threshold, rootMargin }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold, rootMargin, once]);

  return { ref, inView };
}

/* ---------- count-up ---------- */
export function useCountUp(target: number, opts: { duration?: number; decimals?: number } = {}) {
  const { duration = 1600, decimals = 0 } = opts;
  const { ref, inView } = useInView<HTMLSpanElement>({ threshold: 0.4 });
  const [value, setValue] = useState(0);
  const reduced = useReducedMotion();

  useEffect(() => {
    if (!inView) return;
    if (reduced) {
      setValue(target);
      return;
    }
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setValue(target * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, target, duration, reduced]);

  const text = value.toLocaleString("en-US", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
  return { ref, text };
}

/* ---------- scramble / decode word rotator ---------- */
const SCRAMBLE_CHARS = "Z$#D%OHA&@0X1K8≡+";

export function useScramble(words: string[], hold = 2600): string {
  const [text, setText] = useState(words[0] ?? "");
  const reduced = useReducedMotion();
  const wordsRef = useRef(words);
  wordsRef.current = words;

  useEffect(() => {
    const list = wordsRef.current;
    if (list.length <= 1) return;
    let frame = 0;
    let index = 0;

    const scrambleTo = (word: string) => {
      let step = 0;
      const total = Math.max(16, word.length * 3.2);
      const tick = () => {
        step += 1;
        const reveal = Math.floor((step / total) * word.length);
        let out = "";
        for (let c = 0; c < word.length; c += 1) {
          const ch = word[c];
          if (ch === " ") {
            out += " ";
          } else if (c < reveal) {
            out += ch;
          } else {
            out += SCRAMBLE_CHARS[Math.floor(Math.random() * SCRAMBLE_CHARS.length)];
          }
        }
        setText(out);
        if (step < total) {
          frame = requestAnimationFrame(tick);
        } else {
          setText(word);
        }
      };
      frame = requestAnimationFrame(tick);
    };

    if (reduced) {
      const id = window.setInterval(() => {
        index = (index + 1) % list.length;
        setText(list[index]);
      }, hold);
      return () => window.clearInterval(id);
    }

    scrambleTo(list[0]);
    const id = window.setInterval(() => {
      index = (index + 1) % list.length;
      scrambleTo(list[index]);
    }, hold);

    return () => {
      window.clearInterval(id);
      cancelAnimationFrame(frame);
    };
  }, [hold, reduced]);

  return text;
}

/* ---------- scroll position ---------- */
export function useScrolled(offset = 12): boolean {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > offset);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [offset]);
  return scrolled;
}

/* ---------- card spotlight pointer ---------- */
export function useSpotlight() {
  return useCallback((e: React.MouseEvent<HTMLElement>) => {
    const el = e.currentTarget;
    const rect = el.getBoundingClientRect();
    el.style.setProperty("--mx", `${e.clientX - rect.left}px`);
    el.style.setProperty("--my", `${e.clientY - rect.top}px`);
  }, []);
}

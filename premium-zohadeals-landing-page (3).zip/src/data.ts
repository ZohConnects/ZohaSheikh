/* ================= Zoha Sheikh — personal brand content ================= */

/* ---- CONTACT / LINKS (edit these anytime) ---- */
export const contact = {
  name: "Zoha Sheikh",
  role: "Sales Consultant · Community Builder · Founder",
  linkedin: "https://www.linkedin.com/in/zohasheikhsales",
  whatsappNumber: "96565592330",
  phoneDisplay: "+965 6559 2330",
  whatsappMessage: "Hi Zoha! I found your site and I'd love to talk about sales / community.",
  email: "hello@zohasheikh.com",
  photo: "/images/zoha.jpg",
  location: "Working with teams worldwide · Remote-first",
};

export const whatsappUrl = "https://wa.me/96565592330";

/* ---- top ticker ---- */
export const tickerItems = [
  { deal: "Objection Handling Sprint", tag: "1:1", note: "for closers" },
  { deal: "Blue Family Community", tag: "LIVE", note: "join free" },
  { deal: "SocialPilot AI", tag: "SOON", note: "join waitlist" },
  { deal: "Discovery-call teardown", tag: "NEW", note: "book a slot" },
  { deal: "Cold-to-close playbook", tag: "FREE", note: "download" },
  { deal: "Team sales coaching", tag: "AGENCIES", note: "let's talk" },
  { deal: "Founder-led sales audit", tag: "HOT", note: "limited" },
  { deal: "Weekly community calls", tag: "EVERY WK", note: "with Zoha" },
];

/* ---- brands / roles marquee ---- */
export const agencyLogos = [
  "Sales Consulting",
  "Blue Family",
  "SocialPilot AI",
  "Objection Coaching",
  "Community Building",
  "Marketing / Digital",
  "Founder Sales",
  "Team Enablement",
];

export const heroStats = [
  { value: 500, decimals: 0, suffix: "+", label: "community members" },
  { value: 1, decimals: 0, suffix: ":1", label: "sales coaching" },
  { value: 30, decimals: 0, suffix: "+", label: "objections mapped" },
  { value: 100, decimals: 0, suffix: "%", label: "people-first" },
];

/* ---- what I do (bento) ---- */
export type Feature = {
  id: string;
  span: string;
  title: string;
  copy: string;
  visual: "objection" | "coaching" | "community" | "ai" | "audit" | "content";
};

export const features: Feature[] = [
  {
    id: "objections",
    span: "md:col-span-4",
    title: "Objection Handling",
    copy: "\u201cIt's too expensive.\u201d \u201cSend me an email.\u201d \u201cWe're happy with our current vendor.\u201d I help sales teams turn the exact objections that kill deals into the moments that close them \u2014 with scripts, frameworks and real reps.",
    visual: "objection",
  },
  {
    id: "coaching",
    span: "md:col-span-2",
    title: "Team Sales Coaching",
    copy: "Live coaching for marketing & digital agency sales teams \u2014 discovery, demos, follow-up and closing that actually converts.",
    visual: "coaching",
  },
  {
    id: "community",
    span: "md:col-span-2",
    title: "Blue Family Community",
    copy: "A growing home for entrepreneurs, developers, marketers, founders, students & freelancers to learn, connect and grow together.",
    visual: "community",
  },
  {
    id: "audit",
    span: "md:col-span-2",
    title: "Sales Process Audit",
    copy: "I map your funnel, find where deals leak, and hand you a clear plan to fix it \u2014 no fluff, just what moves revenue.",
    visual: "audit",
  },
  {
    id: "socialpilot",
    span: "md:col-span-3",
    title: "SocialPilot AI \u00b7 Coming Soon",
    copy: "An AI that automates your social media handles end-to-end \u2014 posting, replies and growth on autopilot, so founders can stay focused on building.",
    visual: "ai",
  },
  {
    id: "content",
    span: "md:col-span-3",
    title: "Content & Personal Brand",
    copy: "Sales insights, community lessons and founder stories \u2014 the content that builds trust before the first conversation.",
    visual: "content",
  },
];

/* ---- objection showcase steps ---- */
export const showcaseSteps = [
  {
    id: "hear",
    kicker: "Step 01 \u2014 Hear it",
    title: "Name the objection, don't fear it",
    copy: "Most reps freeze the second they hear \u201cwe don't have budget.\u201d I teach teams to recognise the real objection hiding underneath \u2014 price, trust, timing or authority \u2014 so they answer the right one.",
    points: ["Objection library, 30+ mapped", "Root-cause spotting", "Stay calm & curious"],
  },
  {
    id: "reframe",
    kicker: "Step 02 \u2014 Reframe it",
    title: "Turn the wall into a door",
    copy: "Every objection is really a question in disguise. We build proven reframes and stories that acknowledge the concern, shift the frame, and move the buyer forward \u2014 without pushy pressure.",
    points: ["Word-for-word reframes", "Story & proof banks", "Feel-felt-found done right"],
  },
  {
    id: "close",
    kicker: "Step 03 \u2014 Close it",
    title: "Ask for the next step, confidently",
    copy: "Handling the objection is worthless without a clear ask. I coach teams to convert the reframed moment straight into the next commitment \u2014 booked, signed, or scheduled.",
    points: ["Micro-commitments", "Clean closing lines", "Follow-up that lands"],
  },
];

/* ---- why work with me ---- */
export const benefits = [
  {
    num: "01",
    title: "Real sales, not theory",
    copy: "I've lived the calls, the no-shows and the 'let me think about it.' Everything I teach comes from closing real deals in marketing & digital \u2014 not a textbook.",
    metric: "Founder-led & field-tested",
  },
  {
    num: "02",
    title: "People-first, always",
    copy: "Selling isn't tricking people \u2014 it's helping them decide. My frameworks are honest, human and built on genuine trust, which is exactly why they convert.",
    metric: "Trust before the pitch",
  },
  {
    num: "03",
    title: "A community behind you",
    copy: "Blue Family means you're never selling alone. Founders, marketers, developers and freelancers who share what's working \u2014 support that compounds.",
    metric: "500+ members & growing",
  },
  {
    num: "04",
    title: "Building the future of sales",
    copy: "With SocialPilot AI on the way, I bring an automation-first lens \u2014 helping teams do more of what humans do best and letting AI handle the rest.",
    metric: "AI-forward, human-led",
  },
];

/* ---- testimonials ---- */
export const testimonials = [
  {
    quote:
      "The sales audit was accurate and clear. I loved how straight to the point it was — Zoha identified the exact gaps for us. Much appreciated.",
    name: "Agency Partner",
    role: "Client",
    agency: "Sales audit",
    metric: "Gaps found. Straight to the point.",
    initials: "AP",
  },
  {
    quote:
      "Being part of BLUE has given me the opportunity to connect with like-minded people, exchange ideas, and learn from others. I really appreciate the collaborative environment and the opportunities this community creates.",
    name: "Syed Tabish Hashmi",
    role: "Community Member",
    agency: "Blue Family member",
    metric: "Connecting & learning together",
    initials: "ST",
  },
  {
    quote:
      "The Blue Family community is the most genuine group I've been part of. I found collaborators, clients and real friends in one place.",
    name: "Sara M.",
    role: "Freelance Marketer",
    agency: "Blue Family member",
    metric: "3 new clients in 60 days",
    initials: "SM",
  },
  {
    quote:
      "Her objection frameworks are gold. I stopped fearing tough calls and started looking forward to them. That's a mindset shift I can't unlearn.",
    name: "Daniyal K.",
    role: "Account Executive",
    agency: "Marketing Agency",
    metric: "Confidence through the roof",
    initials: "DK",
  },
  {
    quote:
      "Zoha coached our whole team through discovery and closing. Practical, warm and direct \u2014 exactly what a growing agency needs.",
    name: "Hina F.",
    role: "Agency Founder",
    agency: "Growth Studio",
    metric: "Whole team leveled up",
    initials: "HF",
  },
  {
    quote:
      "As a student joining Blue Family, I learned more about real business here than in any course. Zoha genuinely cares.",
    name: "Bilal T.",
    role: "Student & Developer",
    agency: "Blue Family member",
    metric: "From learner to freelancer",
    initials: "BT",
  },
];

/* ---- work-with-me offers ---- */
export type Plan = {
  name: string;
  blurb: string;
  monthly: number;
  annual: number;
  featured?: boolean;
  cta: string;
  priceLabel?: string;
  features: string[];
};

export const plans: Plan[] = [
  {
    name: "Blue Family",
    blurb: "Join the community. Grow with us.",
    monthly: 0,
    annual: 0,
    priceLabel: "Free",
    cta: "Join the community",
    features: [
      "Access to Blue Family network",
      "Weekly community calls",
      "Founders, marketers & devs",
      "Peer support & collabs",
      "Sales tips & resources",
    ],
  },
  {
    name: "1:1 Sales Coaching",
    blurb: "For closers who want an edge.",
    monthly: 150,
    annual: 150,
    priceLabel: "$150",
    featured: true,
    cta: "Book a discovery call",
    features: [
      "Objection-handling mastery",
      "Personalised call reviews",
      "Discovery-to-close frameworks",
      "Scripts & reframe library",
      "Follow-up systems",
      "Direct WhatsApp support",
    ],
  },
  {
    name: "Team Enablement",
    blurb: "For agency & marketing sales teams.",
    monthly: 0,
    annual: 0,
    priceLabel: "Custom",
    cta: "Talk to Zoha",
    features: [
      "Team objection workshops",
      "Sales process audit",
      "Playbooks tailored to you",
      "Live coaching sessions",
      "Ongoing accountability",
      "Quarterly performance review",
    ],
  },
];

export const faqs = [
  {
    q: "Who do you work with?",
    a: "Mainly sales teams and founders in marketing & digital agencies \u2014 but also freelancers, entrepreneurs and anyone who has to sell their work. If deals are stalling on objections, I can help.",
  },
  {
    q: "What exactly is 'objection handling'?",
    a: "It's the skill of responding to the concerns that stop a buyer from saying yes \u2014 price, timing, trust, competitors, authority. I give you frameworks, word-for-word reframes and live practice so tough moments become closing moments.",
  },
  {
    q: "What is the Blue Family Community?",
    a: "Blue Family is a growing community bringing together entrepreneurs, professionals, developers, marketers, founders, students and freelancers \u2014 people with different skills and experiences \u2014 to learn, connect, collaborate and grow together. It's built on genuine support, not just networking.",
  },
  {
    q: "What is SocialPilot AI?",
    a: "SocialPilot AI is a product I'm building that automates your social media handles end-to-end \u2014 scheduling, posting, replies and growth on autopilot. It's coming soon; join the waitlist to get early access.",
  },
  {
    q: "How do we start working together?",
    a: "The easiest way is to message me on WhatsApp or connect on LinkedIn. We'll do a quick discovery call, figure out where your sales are leaking, and pick the right way to work together \u2014 1:1, team coaching, or an audit.",
  },
  {
    q: "Can I just join the community for free?",
    a: "Absolutely. Blue Family is free to join and always will have a free tier. Come learn, share and grow \u2014 no pressure to buy anything.",
  },
];

export const footerColumns = [
  {
    title: "Work with me",
    links: ["Objection handling", "1:1 sales coaching", "Team enablement", "Sales process audit"],
  },
  {
    title: "Blue Family",
    links: ["Join the community", "Weekly calls", "Members", "Collaborate", "Events"],
  },
  {
    title: "SocialPilot AI",
    links: ["What it does", "Join waitlist", "Early access", "Roadmap"],
  },
  {
    title: "Connect",
    links: ["LinkedIn", "WhatsApp", "Email", "About Zoha"],
  },
];

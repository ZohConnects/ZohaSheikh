import { type ReactNode } from "react";
import { features } from "../data";
import { useInView } from "../hooks";
import { whatsappUrl } from "../data";
import { getLinkTarget } from "../utils/links";
import {
  IconArrowUpRight,
  IconBolt,
  IconChart,
  IconFunnel,
  IconSparkles,
  IconStar,
  IconStore,
  IconTarget,
  Reveal,
  SectionHeading,
  SpotCard,
} from "./Atoms";

const iconFor: Record<string, ReactNode> = {
  objection: <IconTarget className="h-5 w-5" />,
  coaching: <IconFunnel className="h-5 w-5" />,
  community: <IconStar className="h-5 w-5" />,
  audit: <IconChart className="h-5 w-5" />,
  ai: <IconSparkles className="h-5 w-5" />,
  content: <IconStore className="h-5 w-5" />,
};

/* ---------- mini visuals ---------- */
function MiniObjection() {
  return (
    <div className="mt-6 space-y-2">
      {[
        ["\u201cIt's too expensive.\u201d", "Reframe value vs. price"],
        ["\u201cSend me an email.\u201d", "Book the next step now"],
        ["\u201cWe're happy already.\u201d", "Open the gap gently"],
      ].map(([q, a], i) => (
        <div
          key={i}
          className="flex items-center justify-between gap-3 rounded-lg border border-white/8 bg-ink-900/70 px-3.5 py-2.5"
        >
          <span className="text-[13px] font-medium text-cream/90">{q}</span>
          <span className="flex shrink-0 items-center gap-1.5 rounded-md bg-volt-400/12 px-2 py-1 font-mono text-[10px] font-semibold text-volt-300">
            {a} <IconArrowUpRight className="h-3 w-3" />
          </span>
        </div>
      ))}
    </div>
  );
}

function MiniCoaching() {
  return (
    <div className="mt-6 rounded-xl border border-white/8 bg-ink-900/70 p-4">
      <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-mist-2">Call review · scored</p>
      <div className="mt-3 space-y-2.5">
        {[
          ["Discovery", 82],
          ["Objections", 74],
          ["Closing", 91],
        ].map(([label, val]) => (
          <div key={label as string}>
            <div className="flex items-center justify-between font-mono text-[10px] text-mist">
              <span>{label}</span>
              <span className="text-cream">{val}%</span>
            </div>
            <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-white/8">
              <div
                className="h-full rounded-full bg-gradient-to-r from-volt-500 to-volt-300"
                style={{ width: `${val}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function MiniCommunity() {
  const roles = ["Founders", "Devs", "Marketers", "Students", "Freelancers", "Pros"];
  return (
    <div className="mt-6 rounded-xl border border-white/8 bg-ink-900/70 p-4">
      <div className="flex flex-wrap gap-1.5">
        {roles.map((r, i) => (
          <span
            key={r}
            className={`rounded-full border px-3 py-1 text-xs font-semibold transition-colors duration-300 ${
              i % 2 === 0
                ? "border-volt-400/40 bg-volt-400/10 text-volt-300"
                : "border-white/10 bg-white/[0.03] text-mist group-hover/spot:border-white/20"
            }`}
          >
            {r}
          </span>
        ))}
      </div>
      <p className="mt-4 flex items-center justify-between font-mono text-[10px] text-mist">
        <span>Blue Family · all skills welcome</span>
        <span className="text-volt-300">500+ ✦</span>
      </p>
    </div>
  );
}

function MiniAudit() {
  const { ref, inView } = useInView<HTMLDivElement>({ threshold: 0.4 });
  const bars = [40, 68, 52, 30, 84, 61];
  const labels = ["Leads", "Qual", "Demo", "Prop", "Close", "Won"];
  return (
    <div ref={ref} className={`mt-6 rounded-xl border border-white/8 bg-ink-900/70 p-4 ${inView ? "bars-in" : ""}`}>
      <div className="flex h-20 items-end gap-2">
        {bars.map((h, i) => (
          <div key={i} className="flex flex-1 flex-col items-center gap-1">
            <div
              className={`bar w-full rounded-sm ${i === 3 ? "bg-ambera-400/80" : "bg-white/12"}`}
              style={{ height: `${h}%`, "--bd": `${i * 70}ms` } as React.CSSProperties}
            />
          </div>
        ))}
      </div>
      <div className="mt-2 flex justify-between font-mono text-[9px] text-mist-2">
        {labels.map((l) => (
          <span key={l}>{l}</span>
        ))}
      </div>
      <p className="mt-2 font-mono text-[10px] text-ambera-300">◆ leak found at proposal stage</p>
    </div>
  );
}

function MiniAi() {
  return (
    <div className="mt-6 rounded-xl border border-white/8 bg-ink-900/70 p-4">
      <div className="flex items-center gap-2 rounded-lg bg-ink-950/90 px-3 py-2">
        <span className="animate-pulse-dot h-1.5 w-1.5 rounded-full bg-volt-400" />
        <span className="font-mono text-[11px] text-mist">
          SocialPilot AI · <b className="text-volt-300">coming soon</b>
        </span>
      </div>
      <div className="mt-3 space-y-2">
        {[
          "Auto-scheduling posts across handles",
          "AI replies & DMs on autopilot",
          "Growth insights, hands-free",
        ].map((t) => (
          <p key={t} className="flex items-center gap-2 text-[12px] text-cream/85">
            <span className="grid h-4 w-4 place-items-center rounded-full bg-volt-400/15 text-volt-300">
              <IconSparkles className="h-2.5 w-2.5" />
            </span>
            {t}
          </p>
        ))}
      </div>
    </div>
  );
}

function MiniContent() {
  return (
    <div className="mt-6 space-y-2">
      {[
        ["How to answer \u201cwe have no budget\u201d", "Sales tip"],
        ["Why community beats cold outreach", "Founder note"],
      ].map(([q, tag], i) => (
        <div key={i} className="flex items-center justify-between gap-3 rounded-xl border border-white/8 bg-ink-900/70 px-4 py-3">
          <p className="text-[13px] font-medium text-cream/90">{q}</p>
          <span className="shrink-0 rounded-md bg-white/6 px-2 py-1 font-mono text-[10px] text-mist">{tag}</span>
        </div>
      ))}
      <p className="px-1 font-mono text-[10px] uppercase tracking-widest text-mist-2">Follow along on LinkedIn</p>
    </div>
  );
}

const visualFor: Record<string, () => ReactNode> = {
  objection: MiniObjection,
  coaching: MiniCoaching,
  community: MiniCommunity,
  audit: MiniAudit,
  ai: MiniAi,
  content: MiniContent,
};

/* ---------- section ---------- */
export default function Features() {
  return (
    <section id="features" aria-labelledby="features-heading" className="relative py-24 sm:py-32">
      <div className="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <SectionHeading
            eyebrow="What I do"
            title={
              <span id="features-heading">
                Helping people <span className="text-volt-400">sell, connect &amp; grow.</span>
              </span>
            }
            sub="From closing tough calls to building a community and shipping AI — here's how I can help you and your team."
          />
          <Reveal delay={200} className="shrink-0">
            <a
              href={whatsappUrl}
              target={getLinkTarget(whatsappUrl)}
              rel="noopener noreferrer"
              className="group inline-flex items-center gap-2 font-display text-sm font-semibold text-cream transition-colors hover:text-volt-300"
            >
              Let's talk
              <span className="grid h-8 w-8 place-items-center rounded-full border border-white/15 transition-all duration-300 group-hover:translate-x-1 group-hover:border-volt-400/50">
                <IconBolt className="h-4 w-4 text-volt-400" />
              </span>
            </a>
          </Reveal>
        </div>

        <div className="mt-14 grid grid-cols-1 gap-5 md:grid-cols-6">
          {features.map((f, i) => {
            const Visual = visualFor[f.visual];
            return (
              <Reveal key={f.id} delay={(i % 3) * 110} className={f.span}>
                <SpotCard className="flex h-full flex-col p-6 sm:p-7">
                  <div className="flex items-center gap-3">
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-volt-400/25 bg-volt-400/10 text-volt-300 transition-transform duration-500 group-hover/spot:rotate-6 group-hover/spot:scale-110">
                      {iconFor[f.visual]}
                    </span>
                    <h3 className="font-display text-lg font-semibold tracking-tight text-cream">{f.title}</h3>
                  </div>
                  <p className="mt-3.5 text-sm leading-relaxed text-mist">{f.copy}</p>
                  <div className="mt-auto">{Visual && <Visual />}</div>
                </SpotCard>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}

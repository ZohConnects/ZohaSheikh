import { contact, whatsappUrl } from "../data";
import {
  ButtonGhost,
  ButtonPrimary,
  IconArrowUpRight,
  IconCheck,
  IconLinkedIn,
  IconSparkles,
  IconWhatsApp,
  Reveal,
  SectionHeading,
} from "./Atoms";

/* ================= About / Founder ================= */
export function About() {
  return (
    <section id="about" aria-labelledby="about-heading" className="relative py-24 sm:py-32">
      <div className="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          {/* photo */}
          <Reveal>
            <div className="relative mx-auto w-full max-w-md">
              <div aria-hidden="true" className="absolute -inset-6 -z-10 rounded-[2rem] bg-volt-400/[0.06] blur-3xl" />
              <div className="relative rounded-[2rem] bg-gradient-to-br from-white/10 via-volt-400/20 to-ambera-400/20 p-px shadow-lift">
                <img
                  src={contact.photo}
                  alt="Zoha Sheikh"
                  loading="lazy"
                  className="aspect-[4/5] w-full rounded-[calc(2rem-1px)] object-cover"
                />
              </div>
              <div className="glass absolute -bottom-5 left-1/2 flex -translate-x-1/2 items-center gap-3 rounded-2xl border border-white/10 px-5 py-3 shadow-lift">
                <span className="grid h-9 w-9 place-items-center rounded-full bg-volt-400/15 font-display text-xs font-bold text-volt-300">
                  ZS
                </span>
                <div>
                  <p className="font-display text-sm font-bold text-cream">{contact.name}</p>
                  <p className="font-mono text-[10px] uppercase tracking-[0.12em] text-mist">{contact.role}</p>
                </div>
              </div>
            </div>
          </Reveal>

          {/* text */}
          <div>
            <SectionHeading
              eyebrow="About me"
              title={
                <span id="about-heading">
                  I sell the way I wish everyone did — <span className="text-volt-400">honestly.</span>
                </span>
              }
            />
            <Reveal delay={150}>
              <div className="mt-6 space-y-4 text-[15px] leading-relaxed text-mist">
                <p>
                  I'm Zoha Sheikh, a sales consultant working in marketing &amp; digital agencies.
                  My focus is simple: help sales teams overcome the objections that stop good deals
                  from closing — with real frameworks, honest conversations and a lot of practice.
                </p>
                <p>
                  Beyond consulting, I founded the <span className="text-cream">Blue Family Community</span>,
                  a growing home for entrepreneurs, professionals, developers, marketers, founders,
                  students and freelancers to connect and grow together. And I'm building{" "}
                  <span className="text-cream">SocialPilot AI</span> — an automation tool for social
                  media handles, launching soon.
                </p>
              </div>
            </Reveal>

            <Reveal delay={250}>
              <ul className="mt-7 grid gap-3 sm:grid-cols-2">
                {[
                  "Sales consultant · agencies",
                  "Objection-handling specialist",
                  "Founder, Blue Family Community",
                  "Building SocialPilot AI",
                ].map((t) => (
                  <li key={t} className="flex items-center gap-2.5 text-sm font-medium text-cream/85">
                    <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-volt-400/15 text-volt-300">
                      <IconCheck className="h-3 w-3" />
                    </span>
                    {t}
                  </li>
                ))}
              </ul>
            </Reveal>

            <Reveal delay={350}>
              <div className="mt-9 flex flex-wrap gap-4">
                <ButtonPrimary href={whatsappUrl}>
                  <IconWhatsApp className="h-4.5 w-4.5" />
                  Chat on WhatsApp
                </ButtonPrimary>
                <ButtonGhost href={contact.linkedin}>
                  <IconLinkedIn className="h-4.5 w-4.5 text-[#4d9fff]" />
                  View LinkedIn
                </ButtonGhost>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ================= Blue Family Community ================= */
export function Community() {
  const roles = [
    "Entrepreneurs",
    "Professionals",
    "Developers",
    "Marketers",
    "Founders",
    "Students",
    "Freelancers",
    "Creators",
  ];
  return (
    <section id="community" aria-labelledby="community-heading" className="relative py-24 sm:py-32">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 -z-10 [background:radial-gradient(650px_400px_at_30%_20%,rgba(77,159,255,0.08),transparent)]"
      />
      <div className="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.1fr] lg:items-center lg:gap-16">
          <div>
            <SectionHeading
              eyebrow="Blue Family Community"
              title={
                <span id="community-heading">
                  You're never selling — or building — <span className="text-volt-400">alone.</span>
                </span>
              }
              sub="A growing community that brings together people with different skills and experiences to learn, connect, collaborate and grow together."
            />
            <Reveal delay={200}>
              <div className="mt-8 flex flex-wrap gap-2.5">
                {roles.map((r, i) => (
                  <span
                    key={r}
                    className={`rounded-full border px-4 py-2 text-sm font-semibold transition-all duration-300 hover:-translate-y-0.5 ${
                      i % 3 === 0
                        ? "border-volt-400/40 bg-volt-400/10 text-volt-300"
                        : "border-white/12 bg-white/[0.03] text-cream/80 hover:border-white/25"
                    }`}
                  >
                    {r}
                  </span>
                ))}
              </div>
            </Reveal>
            <Reveal delay={300}>
              <div className="mt-9">
                <ButtonPrimary href={whatsappUrl}>Join the Blue Family</ButtonPrimary>
              </div>
            </Reveal>
          </div>

          <Reveal delay={200}>
            <div className="grid gap-4 sm:grid-cols-2">
              {[
                { t: "Weekly community calls", d: "Learn, ask questions and share wins with people who get it." },
                { t: "Real collaborations", d: "Find co-founders, clients, partners and friends across skills." },
                { t: "Sales & growth resources", d: "Templates, frameworks and lessons — free for members." },
                { t: "Genuine support", d: "People-first, no ego. We grow by lifting each other up." },
              ].map((c, i) => (
                <div
                  key={c.t}
                  className={`spot-card group rounded-2xl border border-white/8 bg-ink-850/70 p-5 transition-all duration-500 hover:-translate-y-1 hover:border-white/16 ${
                    i % 2 === 1 ? "sm:translate-y-6" : ""
                  }`}
                >
                  <span className="grid h-10 w-10 place-items-center rounded-xl border border-volt-400/25 bg-volt-400/10 text-volt-300">
                    <IconSparkles className="h-5 w-5" />
                  </span>
                  <p className="mt-4 font-display text-base font-semibold text-cream">{c.t}</p>
                  <p className="mt-1.5 text-sm leading-relaxed text-mist">{c.d}</p>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/* ================= SocialPilot AI ================= */
export function SocialPilot() {
  return (
    <section id="socialpilot" aria-labelledby="sp-heading" className="relative py-24 sm:py-32">
      <div className="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
        <Reveal>
          <div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-ink-900">
            <div aria-hidden="true" className="pointer-events-none absolute inset-0">
              <div className="dot-grid absolute inset-0 opacity-50 [mask-image:radial-gradient(70%_80%_at_70%_30%,black,transparent)]" />
              <div className="absolute -right-20 -top-20 h-80 w-80 rounded-full bg-volt-400/12 blur-[100px]" />
              <div className="absolute -bottom-24 left-0 h-72 w-72 rounded-full bg-ambera-400/10 blur-[100px]" />
            </div>

            <div className="relative grid gap-10 p-7 sm:p-12 lg:grid-cols-[1.2fr_1fr] lg:items-center">
              <div>
                <span className="inline-flex items-center gap-2 rounded-full border border-volt-400/30 bg-volt-400/[0.08] px-4 py-1.5 font-mono text-[11px] font-semibold uppercase tracking-[0.2em] text-volt-300">
                  <span className="animate-pulse-dot h-1.5 w-1.5 rounded-full bg-volt-400" />
                  Coming soon
                </span>
                <h2
                  id="sp-heading"
                  className="mt-5 font-display text-3xl font-bold leading-[1.08] tracking-tight text-cream sm:text-5xl"
                >
                  SocialPilot AI
                  <span className="block text-volt-400">social media, on autopilot.</span>
                </h2>
                <p className="mt-5 max-w-lg text-[15px] leading-relaxed text-mist sm:text-lg">
                  An AI that automates your social media handles end-to-end — scheduling, posting,
                  replies and growth — so founders and teams can stay focused on building. Join the
                  waitlist and be first in line.
                </p>

                <ul className="mt-7 grid gap-2.5 sm:grid-cols-2">
                  {[
                    "Auto-post across all handles",
                    "AI replies & DM handling",
                    "Smart scheduling",
                    "Growth analytics",
                  ].map((f) => (
                    <li key={f} className="flex items-center gap-2.5 text-sm font-medium text-cream/85">
                      <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-volt-400/15 text-volt-300">
                        <IconCheck className="h-3 w-3" />
                      </span>
                      {f}
                    </li>
                  ))}
                </ul>

                <div className="mt-9">
                  <ButtonPrimary href={whatsappUrl}>
                    Join the waitlist
                    <IconArrowUpRight className="h-4 w-4" />
                  </ButtonPrimary>
                </div>
              </div>

              {/* mock phone */}
              <div className="relative mx-auto w-full max-w-[280px]">
                <div className="animate-floaty rounded-[2rem] border border-white/12 bg-ink-850 p-3 shadow-lift">
                  <div className="rounded-[1.5rem] bg-ink-950 p-4">
                    <div className="flex items-center justify-between">
                      <span className="font-display text-sm font-bold text-cream">SocialPilot</span>
                      <span className="rounded-md bg-volt-400/15 px-2 py-0.5 font-mono text-[9px] font-bold text-volt-300">
                        AI
                      </span>
                    </div>
                    <div className="mt-4 space-y-2.5">
                      {[
                        ["Instagram", "3 posts scheduled", "#c6f24e"],
                        ["LinkedIn", "reply drafted", "#4d9fff"],
                        ["X / Twitter", "thread queued", "#ffb454"],
                      ].map(([h, s, c]) => (
                        <div key={h} className="flex items-center gap-3 rounded-xl border border-white/8 bg-ink-900 p-3">
                          <span className="h-8 w-8 rounded-lg" style={{ background: c }} />
                          <div>
                            <p className="text-[12px] font-bold text-cream">{h}</p>
                            <p className="font-mono text-[10px] text-mist">{s}</p>
                          </div>
                          <IconCheck className="ml-auto h-4 w-4 text-volt-300" />
                        </div>
                      ))}
                    </div>
                    <div className="mt-4 rounded-xl bg-volt-400/10 p-3 text-center">
                      <p className="font-mono text-[10px] uppercase tracking-widest text-volt-300">
                        Growth this week
                      </p>
                      <p className="font-display text-xl font-bold text-cream">+ 1,240 followers</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

import { useState } from "react";
import { faqs, plans, whatsappUrl } from "../data";
import { getLinkTarget } from "../utils/links";
import { cn } from "../utils/cn";
import {
  ButtonGhost,
  IconArrowUpRight,
  IconCheck,
  IconShield,
  IconWhatsApp,
  Reveal,
  SectionHeading,
} from "./Atoms";

/* ================= Pricing ================= */
export function Pricing() {
  const [annual, setAnnual] = useState(true);

  return (
    <section id="pricing" aria-labelledby="pricing-heading" className="relative py-24 sm:py-32">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 -z-10 [background:radial-gradient(700px_400px_at_50%_0%,rgba(198,242,78,0.05),transparent)]"
      />
      <div className="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
        <SectionHeading
          align="center"
          eyebrow="Work with me"
          title={
            <span id="pricing-heading">
              Pick the way that <span className="text-volt-400">fits you.</span>
            </span>
          }
          sub="Join the community for free, level up 1:1, or bring me in for your whole team. Always people-first."
          className="mx-auto"
        />

        {/* billing toggle */}
        <Reveal delay={200}>
          <div className="mt-10 flex items-center justify-center">
            <div
              role="group"
              aria-label="Billing period"
              className="relative grid grid-cols-2 rounded-full border border-white/10 bg-ink-850/80 p-1"
            >
              <span
                aria-hidden="true"
                className={cn(
                  "absolute inset-y-1 w-[calc(50%-4px)] rounded-full bg-volt-400 transition-transform duration-400 [transition-timing-function:cubic-bezier(0.22,1,0.36,1)]",
                  annual ? "translate-x-[calc(100%+4px)]" : "translate-x-0",
                  "left-1"
                )}
              />
              <button
                type="button"
                aria-pressed={!annual}
                onClick={() => setAnnual(false)}
                className={cn(
                  "relative z-10 rounded-full px-6 py-2.5 font-display text-sm font-semibold transition-colors duration-300",
                  !annual ? "text-ink-950" : "text-mist hover:text-cream"
                )}
              >
                Monthly
              </button>
              <button
                type="button"
                aria-pressed={annual}
                onClick={() => setAnnual(true)}
                className={cn(
                  "relative z-10 rounded-full px-6 py-2.5 font-display text-sm font-semibold transition-colors duration-300",
                  annual ? "text-ink-950" : "text-mist hover:text-cream"
                )}
              >
                Annual
                <span className={cn("ml-2 font-mono text-[10px] font-bold", annual ? "text-ink-950/60" : "text-volt-400")}>
                  −2 MOS
                </span>
              </button>
            </div>
          </div>
        </Reveal>

        {/* plans */}
        <div className="mt-12 grid gap-6 lg:grid-cols-3 lg:items-stretch">
          {plans.map((p, i) => (
            <Reveal key={p.name} delay={i * 120} className="h-full">
              <article
                className={cn(
                  "spot-card group relative flex h-full flex-col rounded-3xl border p-7 transition-all duration-500 hover:-translate-y-1.5 sm:p-8",
                  p.featured
                    ? "border-volt-400/40 bg-gradient-to-b from-volt-400/[0.09] via-ink-850 to-ink-850 shadow-glow lg:-translate-y-3 lg:hover:-translate-y-4"
                    : "border-white/10 bg-ink-850/70 hover:border-white/20"
                )}
              >
                {p.featured && (
                  <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-volt-400 px-4 py-1.5 font-mono text-[10px] font-bold uppercase tracking-[0.16em] text-ink-950">
                    Most booked
                  </span>
                )}
                <h3 className="font-display text-lg font-semibold tracking-tight text-cream">{p.name}</h3>
                <p className="mt-1 text-sm text-mist">{p.blurb}</p>

                <div className="mt-6 flex items-end gap-2" aria-live="polite">
                  <span key={`${p.name}-${annual}`} className="pop-in font-display text-5xl font-bold tracking-tight text-cream">
                    {p.priceLabel ? p.priceLabel : `$${annual ? p.annual : p.monthly}`}
                  </span>
                  {!p.priceLabel && <span className="pb-1.5 font-mono text-xs text-mist-2">/ mo</span>}
                </div>
                <p className="mt-1.5 h-4 font-mono text-[11px] text-mist-2">
                  {p.priceLabel === "Free"
                    ? "always a free tier"
                    : p.priceLabel === "Custom"
                      ? "tailored to your team"
                      : p.priceLabel === "$150"
                        ? "1:1 sales coaching"
                        : annual
                          ? "billed annually · save on 2 months"
                          : "billed monthly · cancel anytime"}
                </p>

                <ul className="mt-7 space-y-3 border-t border-white/8 pt-7">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-3 text-sm text-cream/85">
                      <span
                        className={cn(
                          "mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full",
                          p.featured ? "bg-volt-400/20 text-volt-300" : "bg-white/8 text-mist"
                        )}
                      >
                        <IconCheck className="h-3 w-3" />
                      </span>
                      {f}
                    </li>
                  ))}
                </ul>

                <div className="mt-auto pt-8">
                  {p.featured ? (
                    <a
                      href={whatsappUrl}
                      target={getLinkTarget(whatsappUrl)}
                      rel="noopener noreferrer"
                      className="btn-sheen flex w-full items-center justify-center gap-2 rounded-xl bg-volt-400 py-3.5 font-display text-sm font-bold text-ink-950 transition-transform duration-300 hover:-translate-y-0.5"
                    >
                      {p.cta}
                      <IconArrowUpRight className="h-4 w-4" />
                    </a>
                  ) : (
                    <ButtonGhost href={whatsappUrl} className="w-full justify-center">
                      {p.cta}
                    </ButtonGhost>
                  )}
                </div>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal delay={200}>
          <div className="mt-10 flex flex-col items-center justify-center gap-4 rounded-2xl border border-white/8 bg-ink-850/50 px-6 py-5 text-center sm:flex-row sm:gap-8">
            <p className="flex items-center gap-2.5 font-mono text-[11px] uppercase tracking-[0.16em] text-mist">
              <IconShield className="h-4 w-4 text-volt-400" />
              Honest advice · no pushy sales · people-first
            </p>
            <a
              href={whatsappUrl}
              target={getLinkTarget(whatsappUrl)}
              rel="noopener noreferrer"
              className="group inline-flex items-center gap-1.5 font-display text-sm font-semibold text-volt-300 transition-colors hover:text-volt-200"
            >
              Not sure what fits? Message me
              <IconArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ================= FAQ ================= */
export function Faq() {
  const [open, setOpen] = useState(0);

  return (
    <section id="faq" aria-labelledby="faq-heading" className="relative py-24 sm:py-32">
      <div className="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.5fr] lg:gap-20">
          <div className="lg:sticky lg:top-32 lg:self-start">
            <SectionHeading
              eyebrow="FAQ"
              title={
                <span id="faq-heading">
                  Questions, <span className="text-volt-400">answered.</span>
                </span>
              }
              sub="Everything agency founders ask before their first drop. Anything else — we answer within a business day."
            />
            <Reveal delay={250}>
              <a
                href={whatsappUrl}
                target={getLinkTarget(whatsappUrl)}
                rel="noopener noreferrer"
                className="group mt-8 inline-flex items-center gap-3 rounded-2xl border border-white/10 bg-ink-850/70 px-5 py-4 transition-all duration-300 hover:-translate-y-0.5 hover:border-volt-400/40"
              >
                <span className="grid h-10 w-10 place-items-center rounded-full bg-volt-400/12 text-volt-300" aria-hidden="true">
                  <IconWhatsApp className="h-5 w-5" />
                </span>
                <span>
                  <span className="block font-display text-sm font-semibold text-cream">Ask me directly</span>
                  <span className="block text-xs text-mist">WhatsApp — fastest reply</span>
                </span>
                <IconArrowUpRight className="h-4 w-4 text-mist-2 transition-all duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-volt-300" />
              </a>
            </Reveal>
          </div>

          <div>
            {faqs.map((f, i) => {
              const isOpen = open === i;
              return (
                <Reveal key={f.q} delay={i * 60}>
                  <div className={cn("border-b border-white/8 transition-colors duration-300", isOpen && "bg-white/[0.015]")}>
                    <h3>
                      <button
                        type="button"
                        aria-expanded={isOpen}
                        aria-controls={`faq-panel-${i}`}
                        id={`faq-button-${i}`}
                        onClick={() => setOpen(isOpen ? -1 : i)}
                        className="flex w-full items-center justify-between gap-6 py-5 text-left"
                      >
                        <span
                          className={cn(
                            "font-display text-[15px] font-semibold tracking-tight transition-colors duration-300 sm:text-base",
                            isOpen ? "text-volt-300" : "text-cream"
                          )}
                        >
                          <span className="mr-4 font-mono text-xs text-mist-2">{String(i + 1).padStart(2, "0")}</span>
                          {f.q}
                        </span>
                        <span
                          aria-hidden="true"
                          className={cn(
                            "relative grid h-8 w-8 shrink-0 place-items-center rounded-full border transition-all duration-400",
                            isOpen ? "rotate-45 border-volt-400/50 text-volt-300" : "border-white/15 text-mist"
                          )}
                        >
                          <svg viewBox="0 0 16 16" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
                            <path d="M8 2.5v11M2.5 8h11" />
                          </svg>
                        </span>
                      </button>
                    </h3>
                    <div
                      id={`faq-panel-${i}`}
                      role="region"
                      aria-labelledby={`faq-button-${i}`}
                      className={cn("faq-body", isOpen && "open")}
                    >
                      <div>
                        <p className="max-w-2xl pb-6 pl-0 pr-4 text-[15px] leading-relaxed text-mist sm:pl-10">{f.a}</p>
                      </div>
                    </div>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

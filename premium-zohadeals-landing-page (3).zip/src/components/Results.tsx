import { useEffect, useRef, useState } from "react";
import { benefits, testimonials } from "../data";
import { useReducedMotion } from "../hooks";
import { IconArrowRight, IconStar, Reveal, SectionHeading } from "./Atoms";

/* ================= Benefits ================= */
export function Benefits() {
  return (
    <section id="results" aria-labelledby="results-heading" className="relative py-24 sm:py-32">
      <div className="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.6fr]">
          <div className="lg:sticky lg:top-32 lg:self-start">
            <SectionHeading
              eyebrow="Why work with me"
              title={
                <span id="results-heading">
                  Real sales help, from someone who <span className="text-volt-400">actually sells.</span>
                </span>
              }
              sub="No recycled theory. Just honest, field-tested help for teams and founders who need to close more — the right way."
            />
            <Reveal delay={260}>
              <div className="mt-8 hidden rounded-2xl border border-white/8 bg-ink-850/70 p-5 lg:block">
                <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-mist-2">The sales loop</p>
                <div className="mt-3 flex items-center gap-2 font-mono text-[11px] text-cream/80">
                  {["Talk", "Listen", "Reframe", "Close", "Deliver", "Trust"].map((s, i, arr) => (
                    <span key={s} className="flex items-center gap-2">
                      <span className={i === arr.length - 1 ? "rounded bg-volt-400/15 px-1.5 py-0.5 text-volt-300" : "rounded bg-white/6 px-1.5 py-0.5"}>
                        {s}
                      </span>
                      {i < arr.length - 1 && <span aria-hidden="true" className="text-mist-2">→</span>}
                    </span>
                  ))}
                </div>
                <p className="mt-3 text-xs leading-relaxed text-mist">
                  Every honest close builds trust that makes the next conversation easier. The loop compounds — that's the whole game.
                </p>
              </div>
            </Reveal>
          </div>

          <div>
            {benefits.map((b, i) => (
              <Reveal key={b.num} delay={i * 90}>
                <div className="benefit-row group grid grid-cols-[auto_1fr] items-start gap-5 border-t border-white/8 py-8 transition-transform duration-500 sm:grid-cols-[72px_1fr_auto] sm:gap-8 lg:py-9">
                  <p className="benefit-num font-display text-4xl font-bold tracking-tight sm:text-5xl" aria-hidden="true">
                    {b.num}
                  </p>
                  <div className="group-hover:translate-x-1 transition-transform duration-500">
                    <h3 className="font-display text-xl font-semibold tracking-tight text-cream sm:text-2xl">
                      {b.title}
                    </h3>
                    <p className="mt-2.5 max-w-xl text-[15px] leading-relaxed text-mist">{b.copy}</p>
                  </div>
                  <span className="col-span-2 mt-4 inline-flex w-fit items-center gap-2 rounded-full border border-volt-400/25 bg-volt-400/[0.07] px-3.5 py-1.5 font-mono text-[11px] font-semibold text-volt-300 sm:col-span-1 sm:mt-1">
                    <IconStar className="h-3 w-3 text-ambera-400" />
                    {b.metric}
                  </span>
                </div>
              </Reveal>
            ))}
            <div className="border-t border-white/8" />
          </div>
        </div>
      </div>
    </section>
  );
}

/* ================= Testimonials ================= */
export function Testimonials() {
  const [idx, setIdx] = useState(0);
  const [paused, setPaused] = useState(false);
  const reduced = useReducedMotion();
  const count = testimonials.length;
  const timer = useRef<number | null>(null);

  useEffect(() => {
    if (reduced || paused) return;
    timer.current = window.setInterval(() => setIdx((v) => (v + 1) % count), 6000);
    return () => {
      if (timer.current) window.clearInterval(timer.current);
    };
  }, [reduced, paused, count]);

  const go = (n: number) => setIdx(((n % count) + count) % count);

  return (
    <section
      aria-labelledby="testimonials-heading"
      className="relative overflow-hidden py-24 sm:py-32"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 -z-10 [background:radial-gradient(600px_360px_at_70%_20%,rgba(198,242,78,0.06),transparent)]"
      />
      <div className="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHeading
            eyebrow="Kind words"
            title={
              <span id="testimonials-heading">
                People I've helped <span className="text-volt-400">win.</span>
              </span>
            }
          />
          <Reveal delay={150}>
            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={() => go(idx - 1)}
                aria-label="Previous testimonial"
                className="grid h-11 w-11 place-items-center rounded-full border border-white/12 text-cream transition-all duration-300 hover:-translate-y-0.5 hover:border-volt-400/50 hover:text-volt-300"
              >
                <IconArrowRight className="h-4 w-4 rotate-180" />
              </button>
              <button
                type="button"
                onClick={() => go(idx + 1)}
                aria-label="Next testimonial"
                className="grid h-11 w-11 place-items-center rounded-full border border-white/12 text-cream transition-all duration-300 hover:-translate-y-0.5 hover:border-volt-400/50 hover:text-volt-300"
              >
                <IconArrowRight className="h-4 w-4" />
              </button>
            </div>
          </Reveal>
        </div>

        <Reveal delay={200}>
          <div className="mt-12 overflow-hidden rounded-3xl border border-white/10 bg-ink-850/70 backdrop-blur-sm">
            <div
              className="flex transition-transform duration-700 [transition-timing-function:cubic-bezier(0.22,1,0.36,1)]"
              style={{ transform: `translateX(-${idx * 100}%)` }}
              aria-live="polite"
            >
              {testimonials.map((tm, i) => (
                <figure key={tm.name} className="w-full shrink-0 p-7 sm:p-12" aria-hidden={i !== idx}>
                  <div className="grid gap-8 lg:grid-cols-[1.5fr_1fr] lg:gap-14">
                    <blockquote>
                      <span aria-hidden="true" className="font-display text-6xl leading-none text-volt-400/40">
                        “
                      </span>
                      <p className="mt-2 font-display text-xl font-medium leading-snug tracking-tight text-cream sm:text-2xl lg:text-[1.7rem]">
                        {tm.quote}
                      </p>
                    </blockquote>
                    <figcaption className="flex flex-col justify-end gap-5 lg:border-l lg:border-white/8 lg:pl-10">
                      <span className="w-fit rounded-full border border-volt-400/30 bg-volt-400/[0.08] px-3.5 py-1.5 font-mono text-[11px] font-semibold text-volt-300">
                        {tm.metric}
                      </span>
                      <div className="flex items-center gap-4">
                        <span
                          className="grid h-13 w-13 shrink-0 place-items-center rounded-full bg-[conic-gradient(from_140deg,#c6f24e,#2b5e12,#ffb454,#c6f24e)] p-[2px]"
                          aria-hidden="true"
                        >
                          <span className="grid h-full w-full place-items-center rounded-full bg-ink-900 font-display text-sm font-bold text-cream">
                            {tm.initials}
                          </span>
                        </span>
                        <div>
                          <p className="font-display text-[15px] font-semibold text-cream">{tm.name}</p>
                          <p className="mt-0.5 text-[13px] text-mist">
                            {tm.role} · <span className="text-cream/80">{tm.agency}</span>
                          </p>
                        </div>
                      </div>
                    </figcaption>
                  </div>
                </figure>
              ))}
            </div>
          </div>
        </Reveal>

        <div className="mt-6 flex items-center justify-center gap-2" aria-label="Testimonial navigation">
          {testimonials.map((tm, i) => (
            <button
              key={tm.name}
              type="button"
              aria-current={i === idx}
              aria-label={`Show testimonial from ${tm.name}`}
              onClick={() => go(i)}
              className={`h-1.5 rounded-full transition-all duration-500 ${
                i === idx ? "w-8 bg-volt-400" : "w-2.5 bg-white/15 hover:bg-white/30"
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

import { useState } from "react";
import { contact, footerColumns, whatsappUrl } from "../data";
import { getLinkTarget } from "../utils/links";
import {
  ButtonGhost,
  ButtonPrimary,
  IconArrowRight,
  IconLinkedIn,
  IconStar,
  IconWhatsApp,
  Logo,
  Reveal,
} from "./Atoms";

/* ================= Copyable WhatsApp number ================= */
function CopyNumber() {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(contact.phoneDisplay);
    } catch {
      /* clipboard blocked — the number is still visible on screen */
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="inline-flex flex-wrap items-center justify-center gap-2 rounded-full border border-white/12 bg-ink-950/60 py-2 pl-4 pr-2 backdrop-blur-sm">
      <IconWhatsApp className="h-4 w-4 text-[#25D366]" aria-hidden="true" />
      <a
        href={`tel:${contact.whatsappNumber}`}
        className="font-mono text-sm font-semibold tracking-wide text-cream transition-colors hover:text-volt-300"
      >
        {contact.phoneDisplay}
      </a>
      <button
        type="button"
        onClick={copy}
        className="rounded-full bg-white/8 px-3 py-1.5 font-mono text-[10px] font-bold uppercase tracking-[0.14em] text-mist transition-colors duration-300 hover:bg-volt-400 hover:text-ink-950"
      >
        {copied ? "Copied ✓" : "Copy"}
      </button>
    </div>
  );
}

/* ================= Final CTA ================= */
export function FinalCta() {
  return (
    <section id="cta" aria-labelledby="cta-heading" className="relative py-24 sm:py-32">
      <div className="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
        <Reveal>
          <div className="relative rounded-[2rem] bg-gradient-to-r from-volt-400/45 via-white/12 to-ambera-400/40 p-px">
            <div className="relative overflow-hidden rounded-[calc(2rem-1px)] bg-ink-900 px-6 py-14 text-center sm:px-12 sm:py-20">
              <div aria-hidden="true" className="pointer-events-none absolute inset-0">
                <div className="dot-grid absolute inset-0 opacity-60 [mask-image:radial-gradient(60%_70%_at_50%_30%,black,transparent)]" />
                <div className="absolute -top-24 left-1/2 h-64 w-[520px] -translate-x-1/2 rounded-full bg-volt-400/12 blur-[100px]" />
              </div>

              <div className="relative mx-auto max-w-2xl">
                <p className="inline-flex items-center gap-2 rounded-full border border-volt-400/30 bg-volt-400/[0.08] px-4 py-1.5 font-mono text-[11px] font-medium uppercase tracking-[0.2em] text-volt-300">
                  <span className="animate-pulse-dot h-1.5 w-1.5 rounded-full bg-volt-400" />
                  Let's talk
                </p>

                <h2
                  id="cta-heading"
                  className="mt-6 font-display text-3xl font-bold leading-[1.08] tracking-[-0.02em] text-cream sm:text-5xl"
                >
                  Ready to close more,
                  <span className="block text-volt-400">the honest way?</span>
                </h2>

                <p className="mx-auto mt-5 max-w-xl text-base leading-relaxed text-mist sm:text-lg">
                  Whether you want sales coaching, help handling objections, to join the Blue
                  Family, or early access to SocialPilot AI — I'd love to hear from you. Message
                  me and let's start a conversation.
                </p>

                <div className="mt-9 flex flex-wrap items-center justify-center gap-4">
                  <ButtonPrimary href={whatsappUrl}>
                    <IconWhatsApp className="h-4.5 w-4.5" />
                    Message me on WhatsApp
                  </ButtonPrimary>
                  <ButtonGhost href={contact.linkedin}>
                    <IconLinkedIn className="h-4.5 w-4.5 text-[#4d9fff]" />
                    Connect on LinkedIn
                  </ButtonGhost>
                </div>

                <div className="mt-8 flex flex-col items-center gap-3">
                  <CopyNumber />
                  <a
                    href={`mailto:${contact.email}`}
                    className="group inline-flex items-center gap-2 font-display text-sm font-semibold text-cream/85 transition-colors hover:text-volt-300"
                  >
                    Or email me: {contact.email}
                    <IconArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ================= Footer ================= */
const socials = [
  { name: "Connect on LinkedIn", href: contact.linkedin, icon: "linkedin" as const },
  { name: "Chat on WhatsApp", href: whatsappUrl, icon: "whatsapp" as const },
  { name: "Email Zoha", href: `mailto:${contact.email}`, icon: "mail" as const },
];

export function Footer() {
  return (
    <footer className="relative border-t border-white/8 bg-ink-900/60">
      <div className="mx-auto w-full max-w-[1200px] px-5 py-16 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[1.3fr_2fr]">
          <div>
            <Logo />
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-mist">
              Sales consultant helping marketing &amp; digital agencies overcome objections.
              Founder of Blue Family Community · building SocialPilot AI.
            </p>
            <div className="mt-6 flex items-center gap-2 text-ambera-400" aria-label="Loved by the community">
              {[...Array(5)].map((_, i) => (
                <IconStar key={i} className="h-4 w-4" />
              ))}
              <span className="ml-1 font-mono text-[11px] text-mist">Loved by the Blue Family</span>
            </div>
            <ul className="mt-7 flex gap-3">
              {socials.map((s) => (
                <li key={s.name}>
                  <a
                    href={s.href}
                    target={getLinkTarget(s.href)}
                    rel={s.icon === "mail" ? undefined : "noopener noreferrer"}
                    aria-label={s.name}
                    className="grid h-10 w-10 place-items-center rounded-full border border-white/10 text-mist transition-all duration-300 hover:-translate-y-1 hover:border-volt-400/50 hover:text-volt-300"
                  >
                    {s.icon === "linkedin" ? (
                      <IconLinkedIn className="h-4 w-4" />
                    ) : s.icon === "whatsapp" ? (
                      <IconWhatsApp className="h-4 w-4" />
                    ) : (
                      <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                        <path d="M3.5 6h17v12h-17z" />
                        <path d="m4 7 8 6 8-6" />
                      </svg>
                    )}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <nav aria-label="Footer" className="grid grid-cols-2 gap-8 sm:grid-cols-4">
            {footerColumns.map((col) => (
              <div key={col.title}>
                <h3 className="font-mono text-[11px] font-semibold uppercase tracking-[0.22em] text-mist-2">
                  {col.title}
                </h3>
                <ul className="mt-4 space-y-2.5">
                  {col.links.map((l) => {
                    const href =
                      l === "LinkedIn"
                        ? contact.linkedin
                        : l === "WhatsApp"
                          ? whatsappUrl
                          : l === "Email"
                            ? `mailto:${contact.email}`
                            : l.toLowerCase().includes("waitlist") || l.toLowerCase().includes("join")
                              ? whatsappUrl
                              : "#top";
                    const external = href.startsWith("http") || href.startsWith("mailto");
                    return (
                      <li key={l}>
                        <a
                          href={href}
                          target={getLinkTarget(href)}
                          rel={external && !href.startsWith("mailto") ? "noopener noreferrer" : undefined}
                          className="group inline-flex items-center gap-1.5 text-sm text-mist transition-colors duration-300 hover:text-cream"
                        >
                          <span className="h-px w-0 bg-volt-400 transition-all duration-300 group-hover:w-3" aria-hidden="true" />
                          {l}
                        </a>
                      </li>
                    );
                  })}
                </ul>
              </div>
            ))}
          </nav>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-white/8 pt-7 sm:flex-row">
          <p className="font-mono text-[11px] text-mist-2">
            © 2026 Zoha Sheikh · Sales · Community · AI
          </p>
          <div className="flex items-center gap-6">
            <a href="#about" className="text-xs text-mist transition-colors hover:text-cream">About</a>
            <a href={contact.linkedin} target={getLinkTarget(contact.linkedin)} rel="noopener noreferrer" className="text-xs text-mist transition-colors hover:text-cream">LinkedIn</a>
            <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 font-mono text-[10px] uppercase tracking-widest text-mist">
              <span className="animate-pulse-dot h-1.5 w-1.5 rounded-full bg-volt-400" />
              Open to work
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}

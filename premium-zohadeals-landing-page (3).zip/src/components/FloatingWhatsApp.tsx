import { whatsappUrl } from "../data";
import { getLinkTarget } from "../utils/links";
import { IconWhatsApp } from "./Atoms";

export default function FloatingWhatsApp() {
  return (
    <a
      href={whatsappUrl}
      target={getLinkTarget(whatsappUrl)}
      rel="noopener noreferrer"
      aria-label="Chat with Zoha on WhatsApp"
      className="group fixed bottom-5 right-5 z-[60] flex items-center gap-2 rounded-full bg-[#25D366] py-3 pl-3 pr-4 shadow-[0_12px_30px_-8px_rgba(37,211,102,0.6)] transition-all duration-300 hover:-translate-y-1 sm:bottom-7 sm:right-7"
    >
      <span className="relative grid h-8 w-8 place-items-center rounded-full bg-white/15">
        <span className="animate-pulse-dot absolute inset-0 rounded-full" />
        <IconWhatsApp className="h-5 w-5 text-white" />
      </span>
      <span className="max-w-0 overflow-hidden whitespace-nowrap font-display text-sm font-bold text-white transition-all duration-500 group-hover:max-w-[140px] group-hover:pr-1">
        Chat with me
      </span>
    </a>
  );
}

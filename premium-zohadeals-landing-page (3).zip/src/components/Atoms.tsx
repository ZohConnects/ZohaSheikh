import { type CSSProperties, type ReactNode } from "react";
import { cn } from "../utils/cn";
import { useCountUp, useInView, useSpotlight } from "../hooks";
import { getLinkTarget, isExternal } from "../utils/links";

/* ================= Reveal (scroll entrance) ================= */
export function Reveal({
  children,
  delay = 0,
  className,
  as: Tag = "div",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  as?: "div" | "section" | "li" | "span" | "article" | "figure";
}) {
  const { ref, inView } = useInView<HTMLDivElement>();
  return (
    <Tag
      ref={ref as never}
      className={cn("reveal", inView && "is-in", className)}
      style={{ "--rd": `${delay}ms` } as CSSProperties}
    >
      {children}
    </Tag>
  );
}

/* ================= Eyebrow + heading ================= */
export function SectionHeading({
  eyebrow,
  title,
  sub,
  align = "left",
  className,
}: {
  eyebrow: string;
  title: ReactNode;
  sub?: string;
  align?: "left" | "center";
  className?: string;
}) {
  return (
    <div className={cn("max-w-2xl", align === "center" && "mx-auto text-center", className)}>
      <Reveal>
        <p className="font-mono text-[11px] font-medium uppercase tracking-[0.28em] text-volt-400">
          <span aria-hidden="true" className="mr-2 inline-block h-[1px] w-6 translate-y-[-3px] bg-volt-400/60 align-middle" />
          {eyebrow}
        </p>
      </Reveal>
      <Reveal delay={90}>
        <h2 className="mt-4 font-display text-3xl font-semibold leading-[1.08] tracking-tight text-cream sm:text-4xl lg:text-[2.75rem]">
          {title}
        </h2>
      </Reveal>
      {sub && (
        <Reveal delay={180}>
          <p className="mt-5 text-base leading-relaxed text-mist sm:text-lg">{sub}</p>
        </Reveal>
      )}
    </div>
  );
}

/* ================= Buttons ================= */
export function ButtonPrimary({
  children,
  className,
  href = "#cta",
  type,
  onClick,
}: {
  children: ReactNode;
  className?: string;
  href?: string;
  type?: "button" | "submit";
  onClick?: () => void;
}) {
  const external = isExternal(href);
  return (
    <a
      href={type ? undefined : href}
      onClick={onClick}
      target={getLinkTarget(href)}
      rel={external ? "noopener noreferrer" : undefined}
      className={cn(
        "btn-sheen group inline-flex items-center gap-2.5 rounded-full bg-volt-400 px-6 py-3.5",
        "font-display text-sm font-semibold tracking-tight text-ink-950",
        "shadow-[0_10px_30px_-10px_rgba(198,242,78,0.55)] transition-all duration-300",
        "hover:-translate-y-0.5 hover:bg-volt-300 hover:shadow-[0_18px_40px_-12px_rgba(198,242,78,0.6)]",
        "active:translate-y-0",
        className
      )}
    >
      {children}
      <IconArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
    </a>
  );
}

export function ButtonGhost({
  children,
  className,
  href = "#showcase",
  type,
  onClick,
}: {
  children: ReactNode;
  className?: string;
  href?: string;
  type?: "button" | "submit";
  onClick?: () => void;
}) {
  const external = isExternal(href);
  return (
    <a
      href={type ? undefined : href}
      onClick={onClick}
      target={getLinkTarget(href)}
      rel={external ? "noopener noreferrer" : undefined}
      className={cn(
        "group inline-flex items-center gap-2.5 rounded-full border border-white/12 bg-white/[0.03] px-6 py-3.5",
        "font-display text-sm font-semibold tracking-tight text-cream",
        "backdrop-blur-sm transition-all duration-300 hover:-translate-y-0.5 hover:border-volt-400/40 hover:bg-white/[0.06]",
        className
      )}
    >
      {children}
    </a>
  );
}

/* ================= Spotlight card wrapper ================= */
export function SpotCard({
  children,
  className,
  hover = true,
}: {
  children: ReactNode;
  className?: string;
  hover?: boolean;
}) {
  const onMove = useSpotlight();
  return (
    <div
      onMouseMove={onMove}
      className={cn(
        "spot-card group/spot relative rounded-2xl border border-white/8 bg-ink-850/80",
        hover && "transition-all duration-500 hover:-translate-y-1 hover:border-white/14 hover:bg-ink-800/90",
        className
      )}
    >
      {children}
    </div>
  );
}

/* ================= Logo ================= */
export function Logo({ className }: { className?: string }) {
  return (
    <a href="#top" className={cn("group inline-flex items-center gap-2.5", className)} aria-label="Zoha Sheikh — back to top">
      <span className="relative grid h-9 w-9 place-items-center rounded-xl border border-volt-400/30 bg-volt-400/10 font-display text-sm font-bold text-volt-300 transition-colors duration-300 group-hover:bg-volt-400/20">
        ZS
      </span>
      <span className="font-display text-lg font-bold tracking-tight text-cream">
        Zoha<span className="text-volt-400"> Sheikh</span>
      </span>
    </a>
  );
}

/* ================= Icons (custom, 1.5 stroke) ================= */
type IconProps = { className?: string };
const S = {
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.7,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

export const IconArrowRight = ({ className }: IconProps) => (
  <svg viewBox="0 0 20 20" className={className} aria-hidden="true">
    <path d="M3 10h13M11.5 4.5 17 10l-5.5 5.5" {...S} />
  </svg>
);

export const IconArrowUpRight = ({ className }: IconProps) => (
  <svg viewBox="0 0 20 20" className={className} aria-hidden="true">
    <path d="M5 15 15 5M7.5 5H15v7.5" {...S} />
  </svg>
);

export const IconCheck = ({ className }: IconProps) => (
  <svg viewBox="0 0 20 20" className={className} aria-hidden="true">
    <path d="m4 10.5 4 4L16 6" {...S} strokeWidth={2} />
  </svg>
);

export const IconPlay = ({ className }: IconProps) => (
  <svg viewBox="0 0 20 20" className={className} aria-hidden="true">
    <circle cx="10" cy="10" r="8.2" {...S} strokeWidth={1.4} />
    <path d="M8.2 7.2 13 10l-4.8 2.8Z" fill="currentColor" stroke="none" />
  </svg>
);

export const IconStar = ({ className }: IconProps) => (
  <svg viewBox="0 0 20 20" className={className} aria-hidden="true">
    <path
      d="m10 2.6 2.2 4.6 5 .7-3.6 3.5.9 5-4.5-2.4-4.5 2.4.9-5L2.8 7.9l5-.7L10 2.6Z"
      fill="currentColor"
      stroke="none"
    />
  </svg>
);

export const IconTag = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
    <path d="M3.5 11.6V5a1.5 1.5 0 0 1 1.5-1.5h6.6a2 2 0 0 1 1.4.6l7.4 7.4a2 2 0 0 1 0 2.8l-5.9 5.9a2 2 0 0 1-2.8 0L4.1 12.4a2 2 0 0 1-.6-1.4Z" {...S} />
    <circle cx="8.6" cy="8.6" r="1.6" {...S} strokeWidth={1.5} />
  </svg>
);

export const IconTarget = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
    <circle cx="12" cy="12" r="8.5" {...S} />
    <circle cx="12" cy="12" r="4.6" {...S} />
    <circle cx="12" cy="12" r="1.2" fill="currentColor" stroke="none" />
    <path d="M12 1.8v3M12 19.2v3M1.8 12h3M19.2 12h3" {...S} />
  </svg>
);

export const IconBolt = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
    <path d="M13.2 2.5 4.8 13.4h5.4l-1.4 8.1 8.4-10.9h-5.4l1.4-8.1Z" {...S} />
  </svg>
);

export const IconFunnel = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
    <path d="M3.5 4.5h17l-6.4 7.4v6.2l-4.2 2.4v-8.6L3.5 4.5Z" {...S} />
  </svg>
);

export const IconChart = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
    <path d="M3.5 3.5v16a1 1 0 0 0 1 1h16" {...S} />
    <path d="M7.5 15.5v-4M12 15.5V8.5M16.5 15.5v-5.5M20.5 15.5v-9" {...S} strokeWidth={2.2} />
  </svg>
);

export const IconStore = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
    <path d="M4 9.5 5.6 4h12.8L20 9.5M4 9.5a2.4 2.4 0 0 0 4 1.6 2.4 2.4 0 0 0 4 0 2.4 2.4 0 0 0 4 0 2.4 2.4 0 0 0 4-1.6M5.5 12v8h13v-8M9.5 20v-5h5v5" {...S} />
  </svg>
);

export const IconSparkles = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
    <path d="M12 3.5 13.8 9l5.5 1.8-5.5 1.8L12 18l-1.8-5.4L4.7 10.8 10.2 9 12 3.5Z" {...S} />
    <path d="M19 16.5 19.7 18.5l2 .7-2 .7L19 20l-.7-2.1-2-.7 2-.7.7-2Z" fill="currentColor" stroke="none" />
  </svg>
);

export const IconMenu = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
    <path d="M4 7h16M4 12h16M4 17h10" {...S} strokeWidth={2} />
  </svg>
);

export const IconX = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
    <path d="m6 6 12 12M18 6 6 18" {...S} strokeWidth={2} />
  </svg>
);

export const IconChevron = ({ className }: IconProps) => (
  <svg viewBox="0 0 20 20" className={className} aria-hidden="true">
    <path d="m5.5 8 4.5 4.5L14.5 8" {...S} strokeWidth={2} />
  </svg>
);

export const IconShield = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
    <path d="M12 3 5 5.8v5.4c0 4.5 3 7.7 7 9.3 4-1.6 7-4.8 7-9.3V5.8L12 3Z" {...S} />
    <path d="m9 11.6 2.2 2.2L15.4 9.4" {...S} />
  </svg>
);

export const IconLinkedIn = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true">
    <path d="M4.98 3.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5ZM3 9.5h4V20.5H3V9.5Zm6.5 0h3.8v1.5h.1c.5-1 1.8-2 3.7-2 4 0 4.7 2.6 4.7 6v5.5h-4v-4.9c0-1.2 0-2.7-1.6-2.7s-1.9 1.3-1.9 2.6v5H9.5V9.5Z" />
  </svg>
);

export const IconWhatsApp = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true">
    <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.9c0 1.75.46 3.45 1.32 4.95L2 22l5.3-1.38a9.9 9.9 0 0 0 4.74 1.2h.01c5.46 0 9.9-4.45 9.9-9.9 0-2.65-1.03-5.14-2.9-7.01A9.82 9.82 0 0 0 12.04 2Zm0 1.8c2.16 0 4.19.84 5.72 2.37a8.06 8.06 0 0 1 2.37 5.73c0 4.47-3.63 8.1-8.1 8.1a8.1 8.1 0 0 1-4.13-1.13l-.3-.18-3.14.82.84-3.06-.2-.31a8.05 8.05 0 0 1-1.24-4.3c0-4.47 3.64-8.1 8.11-8.1Zm-2.66 4.3c-.13 0-.34.05-.52.24-.18.2-.68.67-.68 1.63s.7 1.9.8 2.03c.1.13 1.38 2.1 3.34 2.95.47.2.83.32 1.11.41.47.15.9.13 1.24.08.38-.06 1.16-.47 1.32-.93.16-.46.16-.85.11-.93-.05-.08-.18-.13-.38-.23-.2-.1-1.16-.57-1.34-.64-.18-.06-.31-.1-.44.1-.13.2-.5.64-.62.77-.11.13-.23.15-.42.05a5.4 5.4 0 0 1-1.6-.99 6 6 0 0 1-1.1-1.38c-.12-.2-.01-.3.09-.4.09-.09.2-.23.29-.35.1-.12.13-.2.2-.34.06-.13.03-.25-.02-.35-.05-.1-.44-1.07-.6-1.46-.16-.38-.32-.33-.44-.34l-.37-.01Z" />
  </svg>
);

/* ================= Stat (count-up) ================= */
export function Stat({
  value,
  decimals = 0,
  suffix = "",
  prefix = "",
  label,
}: {
  value: number;
  decimals?: number;
  suffix?: string;
  prefix?: string;
  label: string;
}) {
  const { ref, text } = useCountUp(value, { decimals });
  return (
    <div>
      <p className="font-display text-3xl font-bold tracking-tight text-cream sm:text-4xl">
        <span ref={ref}>
          {prefix}
          {text}
        </span>
        <span className="text-volt-400">{suffix}</span>
      </p>
      <p className="mt-1.5 font-mono text-[11px] uppercase tracking-[0.16em] text-mist">{label}</p>
    </div>
  );
}

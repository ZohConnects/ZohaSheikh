import { type ReactNode } from "react";
import { showcaseSteps } from "../data";
import { IconArrowUpRight, IconCheck, SectionHeading } from "./Atoms";

/* ---------- Step 01: Hear it ---------- */
function MockHear() {
  const objs = [
    ["\u201cIt's too expensive.\u201d", "Price", "#ffb454"],
    ["\u201cWe already have a vendor.\u201d", "Competitor", "#4d9fff"],
    ["\u201cNot the right time.\u201d", "Timing", "#c6f24e"],
    ["\u201cI need to ask my boss.\u201d", "Authority", "#f29a2b"],
  ];
  return (
    <div className="rounded-2xl border border-white/8 bg-ink-950/70 p-5">
      <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-mist-2">Objection library · 30+ mapped</p>
      <div className="mt-4 space-y-2.5">
        {objs.map(([q, type, c]) => (
          <div key={q} className="flex items-center justify-between gap-3 rounded-xl border border-white/8 bg-ink-900 px-4 py-3">
            <span className="text-[13px] font-medium text-cream/90">{q}</span>
            <span
              className="shrink-0 rounded-md px-2 py-1 font-mono text-[10px] font-bold"
              style={{ background: `${c}22`, color: c }}
            >
              {type}
            </span>
          </div>
        ))}
      </div>
      <p className="mt-4 font-mono text-[11px] text-volt-300">◆ Answer the real one, not the surface one</p>
    </div>
  );
}

/* ---------- Step 02: Reframe it ---------- */
function MockReframe() {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <div className="rounded-2xl border border-white/8 bg-ink-950/70 p-5">
        <p className="font-mono text-[10px] uppercase tracking-widest text-ambera-300">They say</p>
        <p className="mt-3 text-[15px] font-semibold leading-snug text-cream">
          “It's too expensive for us right now.”
        </p>
        <div className="mt-4 h-px bg-white/8" />
        <p className="mt-3 font-mono text-[10px] text-mist-2">Wall</p>
      </div>
      <div className="rounded-2xl border border-volt-400/25 bg-gradient-to-b from-volt-400/[0.09] to-transparent p-5">
        <p className="font-mono text-[10px] uppercase tracking-widest text-volt-300">You reframe</p>
        <p className="mt-3 text-[15px] font-semibold leading-snug text-cream">
          “Totally fair — most clients felt that until they saw what one closed deal returns. Can I show you?”
        </p>
        <div className="mt-4 flex items-center gap-1.5">
          <IconArrowUpRight className="h-3.5 w-3.5 text-volt-300" />
          <p className="font-mono text-[10px] text-volt-300">Door</p>
        </div>
      </div>
      <div className="sm:col-span-2 flex flex-wrap gap-2 rounded-xl border border-white/8 bg-ink-950/70 p-3">
        {["Acknowledge", "Reframe", "Proof", "Move forward"].map((s) => (
          <span key={s} className="rounded-md bg-volt-400/12 px-2.5 py-1 font-mono text-[10px] font-semibold text-volt-300">
            {s} ✓
          </span>
        ))}
      </div>
    </div>
  );
}

/* ---------- Step 03: Close it ---------- */
function MockClose() {
  const steps: [string, string, boolean][] = [
    ["Micro-commitment", "“Does this make sense so far?”", true],
    ["Trial close", "“If we solved that, would you move ahead?”", true],
    ["The ask", "“Let's get you started — Thursday work?”", true],
    ["Next step booked", "Intro call · Thu 10:00", false],
  ];
  return (
    <div className="rounded-2xl border border-white/8 bg-ink-950/70 p-5">
      <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-mist-2">Closing sequence</p>
      <div className="mt-4 space-y-2.5">
        {steps.map(([label, line, last], i) => (
          <div
            key={label}
            className={`flex items-start gap-3 rounded-xl border p-3 ${
              !last && i === steps.length - 1 ? "border-volt-400/30 bg-volt-400/[0.07]" : "border-white/8 bg-ink-900"
            }`}
          >
            <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-volt-400/15 text-volt-300">
              <IconCheck className="h-3 w-3" />
            </span>
            <div>
              <p className="text-[12px] font-bold text-cream">{label}</p>
              <p className="font-mono text-[11px] text-mist">{line}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-4 inline-flex items-center gap-2 rounded-full border border-volt-400/30 bg-volt-400/[0.08] px-3.5 py-1.5 font-mono text-[11px] text-volt-300">
        <IconCheck className="h-3.5 w-3.5" /> Deal moved forward · not lost
      </div>
    </div>
  );
}

/* ---------- section ---------- */
export default function Showcase() {
  const mocks: Record<string, ReactNode> = {
    hear: <MockHear />,
    reframe: <MockReframe />,
    close: <MockClose />,
  };

  return (
    <section id="showcase" aria-labelledby="showcase-heading" className="relative py-24 sm:py-32">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-[10%] top-[20%] h-[300px] w-[300px] rounded-full bg-volt-400/[0.05] blur-[110px]" />
      </div>

      <div className="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
        <SectionHeading
          eyebrow="Objection handling"
          align="center"
          title={
            <span id="showcase-heading">
              Turn every objection into a <span className="text-volt-400">yes.</span>
            </span>
          }
          sub="My simple 3-step method that helps sales teams stop fearing tough moments — and start closing them."
        />

        <div className="mt-16 space-y-8">
          {showcaseSteps.map((s, i) => (
            <div key={s.id} className="lg:sticky" style={{ top: `${104 + i * 22}px`, zIndex: 10 + i }}>
              <article className="stack-card overflow-hidden rounded-3xl border border-white/10 bg-ink-900/95 backdrop-blur-md">
                <div className="hairline-top grid gap-8 p-6 sm:p-9 lg:grid-cols-[1fr_1.35fr] lg:gap-12">
                  <div className="flex flex-col justify-center">
                    <p className="font-mono text-[11px] font-medium uppercase tracking-[0.26em] text-volt-400">{s.kicker}</p>
                    <h3 className="mt-3 font-display text-2xl font-semibold tracking-tight text-cream sm:text-3xl">
                      {s.title}
                    </h3>
                    <p className="mt-4 text-[15px] leading-relaxed text-mist">{s.copy}</p>
                    <ul className="mt-6 space-y-2.5">
                      {s.points.map((p) => (
                        <li key={p} className="flex items-center gap-2.5 text-sm font-medium text-cream/85">
                          <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-volt-400/15 text-volt-300">
                            <IconCheck className="h-3 w-3" />
                          </span>
                          {p}
                        </li>
                      ))}
                    </ul>
                    <p className="mt-8 hidden font-display text-5xl font-bold text-white/8 lg:block" aria-hidden="true">
                      {String(i + 1).padStart(2, "0")}
                      <span className="text-white/20"> / 03</span>
                    </p>
                  </div>
                  <div className="min-w-0">{mocks[s.id]}</div>
                </div>
              </article>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

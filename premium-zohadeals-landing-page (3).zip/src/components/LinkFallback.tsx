import { useEffect, useState } from "react";
import { contact } from "../data";
import { LINK_BLOCKED_EVENT } from "../utils/links";
import { IconWhatsApp, IconX } from "./Atoms";

/**
 * Shown only when the browser (or a sandboxed preview frame) refuses to open
 * an external link, so a click never silently does nothing.
 */
export default function LinkFallback() {
  const [url, setUrl] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const onBlocked = (e: Event) => {
      const detail = (e as CustomEvent<{ url: string }>).detail;
      if (detail?.url) setUrl(detail.url);
    };
    window.addEventListener(LINK_BLOCKED_EVENT, onBlocked);
    return () => window.removeEventListener(LINK_BLOCKED_EVENT, onBlocked);
  }, []);

  useEffect(() => {
    if (!url) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setUrl(null);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [url]);

  if (!url) return null;

  const isWhatsApp = /wa\.me|whatsapp/i.test(url);
  const value = isWhatsApp ? contact.phoneDisplay : url;

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      /* clipboard unavailable — the value is visible on screen */
    }
  };

  return (
    <div
      className="fixed inset-0 z-[90] flex items-center justify-center bg-ink-950/80 p-5 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="fallback-title"
      onClick={() => setUrl(null)}
    >
      <div
        className="relative w-full max-w-sm rounded-2xl border border-white/12 bg-ink-850 p-6 shadow-lift"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={() => setUrl(null)}
          aria-label="Close"
          className="absolute right-4 top-4 grid h-8 w-8 place-items-center rounded-full border border-white/12 text-mist transition-colors hover:border-volt-400/50 hover:text-cream"
        >
          <IconX className="h-4 w-4" />
        </button>

        <span className="grid h-11 w-11 place-items-center rounded-xl bg-[#25D366]/15 text-[#25D366]">
          <IconWhatsApp className="h-6 w-6" />
        </span>

        <h2 id="fallback-title" className="mt-4 font-display text-lg font-bold text-cream">
          {isWhatsApp ? "Message Zoha on WhatsApp" : "Open this link"}
        </h2>
        <p className="mt-2 text-sm leading-relaxed text-mist">
          Your browser blocked the pop-up. Use the link below, or save the number and message
          Zoha directly.
        </p>

        <a
          href={url}
          target="_top"
          rel="noopener noreferrer"
          className="btn-sheen mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-volt-400 py-3.5 font-display text-sm font-bold text-ink-950"
        >
          {isWhatsApp ? "Open WhatsApp chat" : "Continue"}
        </a>

        <div className="mt-3 flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-ink-950/70 px-4 py-3">
          <span className="truncate font-mono text-sm text-cream">{value}</span>
          <button
            type="button"
            onClick={copy}
            className="shrink-0 rounded-full bg-white/8 px-3 py-1.5 font-mono text-[10px] font-bold uppercase tracking-[0.14em] text-mist transition-colors hover:bg-volt-400 hover:text-ink-950"
          >
            {copied ? "Copied ✓" : "Copy"}
          </button>
        </div>
      </div>
    </div>
  );
}

import { agencyLogos, contact, heroStats, tickerItems, whatsappUrl } from "../data";
import { useScramble } from "../hooks";
import {
  ButtonGhost,
  ButtonPrimary,
  IconCheck,
  IconLinkedIn,
  IconWhatsApp,
  Reveal,
  Stat,
} from "./Atoms";

/* ---------- ticker ---------- */
function DealsTicker() {
  const row = (hidden: boolean) => (
    <div aria-hidden={hidden || undefined} className="flex shrink-0 items-center">
      {tickerItems.map((t, i) => (
        <span key={i} className="flex items-center gap-2.5 px-5 font-mono text-[11px] tracking-wide text-mist">
          <span
            className={`rounded-md px-1.5 py-0.5 text-[10px] font-semibold ${
              t.tag === "FREE" || t.tag === "LIVE"
                ? "bg-volt-400/15 text-volt-300"
                : t.tag === "HOT" || t.tag === "SOON" || t.tag === "NEW"
                  ? "bg-ambera-400/15 text-ambera-300"
                  : "bg-white/8 text-cream/80"
            }`}
          >
            {t.tag}
          </span>
          <span className="whitespace-nowrap text-cream/85">{t.deal}</span>
          <span className="whitespace-nowrap text-mist-2">· {t.note}</span>
          <span aria-hidden="true" className="ml-4 text-volt-400/50">
            ◆
          </span>
        </span>
      ))}
    </div>
  );
  return (
    <div className="marquee border-b border-white/6 bg-ink-900/50 py-3" aria-label="What Zoha offers">
      <div className="marquee-track">
        {row(false)}
        {row(true)}
      </div>
    </div>
  );
}

/* ---------- hero visual: founder photo ---------- */
function HeroVisual() {
  return (
    <div className="relative mx-auto w-full max-w-[440px] lg:max-w-none">
      {/* ambient */}
      <div aria-hidden="true" className="absolute -inset-10 -z-10">
        <div className="dot-grid absolute inset-0 rounded-[2.5rem] opacity-70 [mask-image:radial-gradient(70%_70%_at_50%_40%,black,transparent)]" />
        <div className="absolute left-1/2 top-1/2 h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-volt-400/10 blur-[90px]" />
        <div className="animate-spin-slow absolute left-1/2 top-1/2 h-[500px] w-[500px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-dashed border-white/8" />
      </div>

      {/* photo frame */}
      <div className="relative rounded-[2rem] bg-gradient-to-br from-volt-400/40 via-white/10 to-ambera-400/30 p-px shadow-lift">
        <div className="relative overflow-hidden rounded-[calc(2rem-1px)] bg-ink-850">
          <img
            src={contact.photo}
            alt="Zoha Sheikh, sales consultant and founder of Blue Family Community"
            loading="eager"
            className="aspect-square w-full object-cover"
          />
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink-950/70 via-transparent to-transparent" />
          <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
            <div className="glass rounded-2xl border border-white/10 px-4 py-2.5">
              <p className="font-display text-sm font-bold text-cream">Zoha Sheikh</p>
              <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-volt-300">
                Sales · Community · AI
              </p>
            </div>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-volt-400/90 px-3 py-1.5 font-mono text-[10px] font-bold uppercase tracking-[0.14em] text-ink-950">
              <span className="animate-pulse-dot h-1.5 w-1.5 rounded-full bg-ink-950" />
              Available
            </span>
          </div>
        </div>
      </div>

      {/* floating: objection card */}
      <div className="animate-floaty absolute -right-3 -top-8 hidden w-56 items-center gap-3 rounded-2xl border border-white/10 bg-ink-800/95 px-4 py-3 shadow-lift backdrop-blur-md sm:flex lg:-right-10">
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-volt-400/15 text-volt-300">
          <IconCheck className="h-4 w-4" />
        </span>
        <div>
          <p className="text-[13px] font-bold text-cream">“It's too expensive”</p>
          <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-mist">→ turned into a close</p>
        </div>
      </div>

      {/* floating: community card */}
      <div className="animate-floaty-2 absolute -bottom-10 -left-3 w-52 rounded-2xl border border-white/10 bg-ink-800/95 p-4 shadow-lift backdrop-blur-md sm:-left-10">
        <div className="flex items-baseline justify-between">
          <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-mist">Blue Family</p>
          <p className="font-mono text-[11px] font-semibold text-volt-300">growing</p>
        </div>
        <p className="mt-1 font-display text-2xl font-bold text-cream">500+ members</p>
        <div className="mt-2 flex -space-x-2" aria-hidden="true">
          {["#c6f24e", "#ffb454", "#4d9fff", "#f29a2b", "#aede2f"].map((c, i) => (
            <span
              key={i}
              className="h-6 w-6 rounded-full border-2 border-ink-800"
              style={{ background: c }}
            />
          ))}
          <span className="grid h-6 w-6 place-items-center rounded-full border-2 border-ink-800 bg-white/10 font-mono text-[9px] text-cream">
            +
          </span>
        </div>
      </div>
    </div>
  );
}

/* ---------- section ---------- */
export default function Hero() {
  const word = useScramble(["closed deals.", "confidence.", "community.", "clients."], 3000);

  return (
    <section id="top" aria-labelledby="hero-heading" className="relative">
      <DealsTicker />

      <div className="relative mx-auto w-full max-w-[1200px] px-5 pb-24 pt-16 sm:px-8 sm:pt-20 lg:pb-28">
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute -top-24 right-[8%] h-[380px] w-[380px] rounded-full bg-volt-400/[0.07] blur-[100px]" />
          <div className="absolute bottom-0 left-[4%] h-[300px] w-[300px] rounded-full bg-ambera-400/[0.05] blur-[100px]" />
        </div>

        <div className="grid items-center gap-14 lg:grid-cols-12 lg:gap-8">
          <div className="lg:col-span-7">
            <Reveal>
              <p className="inline-flex items-center gap-2.5 rounded-full border border-white/10 bg-white/[0.03] py-1.5 pl-2 pr-4 text-[13px] font-medium text-mist backdrop-blur-sm">
                <span className="rounded-full bg-volt-400/15 px-2.5 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-[0.14em] text-volt-300">
                  Hi, I'm Zoha
                </span>
                Sales consultant · founder of Blue Family
              </p>
            </Reveal>

            <Reveal delay={110}>
              <h1
                id="hero-heading"
                className="mt-6 font-display text-[2.5rem] font-bold leading-[1.05] tracking-[-0.02em] text-cream sm:text-6xl lg:text-[4rem]"
              >
                I turn objections
                <span className="mt-1 block text-volt-400">
                  into <span className="inline-block min-w-[9ch]">{word}</span>
                </span>
              </h1>
            </Reveal>

            <Reveal delay={220}>
              <p className="mt-6 max-w-xl text-lg leading-relaxed text-mist">
                I help sales teams in marketing &amp; digital agencies overcome the objections
                that kill deals. I'm also the founder of the{" "}
                <span className="text-cream">Blue Family Community</span> and I'm building{" "}
                <span className="text-cream">SocialPilot AI</span> — automated social media, coming soon.
              </p>
            </Reveal>

            <Reveal delay={330}>
              <div className="mt-9 flex flex-wrap items-center gap-4">
                <ButtonPrimary href={whatsappUrl}>
                  <IconWhatsApp className="h-4.5 w-4.5" />
                  Message me on WhatsApp
                </ButtonPrimary>
                <ButtonGhost href={contact.linkedin}>
                  <IconLinkedIn className="h-4.5 w-4.5 text-[#4d9fff]" />
                  Connect on LinkedIn
                </ButtonGhost>
              </div>
            </Reveal>

            <Reveal delay={430}>
              <p className="mt-6 font-mono text-[11px] uppercase tracking-[0.18em] text-mist-2">
                Sales coaching · Objection handling · Community · {contact.location}
              </p>
            </Reveal>
          </div>

          <div className="lg:col-span-5">
            <Reveal delay={260}>
              <HeroVisual />
            </Reveal>
          </div>
        </div>

        {/* stats */}
        <Reveal delay={150}>
          <dl className="mt-24 grid grid-cols-2 gap-x-6 gap-y-10 border-t border-white/8 pt-10 sm:grid-cols-4">
            {heroStats.map((s) => (
              <Stat key={s.label} {...s} />
            ))}
          </dl>
        </Reveal>

        {/* marquee of focus areas */}
        <div className="mt-16">
          <Reveal>
            <p className="text-center font-mono text-[11px] uppercase tracking-[0.28em] text-mist-2">
              What I focus on
            </p>
          </Reveal>
          <div className="marquee mt-6" aria-hidden="true">
            <div className="marquee-track slow">
              {[0, 1].map((dup) => (
                <div key={dup} className="flex shrink-0 items-center">
                  {agencyLogos.map((name, i) => (
                    <span
                      key={`${dup}-${i}`}
                      className="mx-9 font-display text-xl font-semibold tracking-tight text-cream/35 transition-colors duration-300 hover:text-cream/70"
                    >
                      {name}
                    </span>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

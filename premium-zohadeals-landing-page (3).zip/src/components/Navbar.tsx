import { useState } from "react";
import { cn } from "../utils/cn";
import { useScrolled } from "../hooks";
import { contact, whatsappUrl } from "../data";
import { getLinkTarget } from "../utils/links";
import {
  ButtonPrimary,
  IconArrowRight,
  IconLinkedIn,
  IconMenu,
  IconWhatsApp,
  IconX,
  Logo,
} from "./Atoms";

const links = [
  { label: "What I do", href: "#features" },
  { label: "Objections", href: "#showcase" },
  { label: "Community", href: "#community" },
  { label: "SocialPilot AI", href: "#socialpilot" },
  { label: "Work with me", href: "#pricing" },
];

export default function Navbar() {
  const scrolled = useScrolled(24);
  const [open, setOpen] = useState(false);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled ? "glass border-b border-white/8 py-3" : "border-b border-transparent py-5"
      )}
    >
      <div className="mx-auto flex w-full max-w-[1200px] items-center justify-between px-5 sm:px-8">
        <Logo />

        <nav aria-label="Primary" className="hidden items-center gap-1 xl:flex">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="group relative rounded-full px-4 py-2 text-sm font-medium text-mist transition-colors duration-300 hover:text-cream"
            >
              {l.label}
              <span
                aria-hidden="true"
                className="absolute inset-x-4 -bottom-px h-px origin-left scale-x-0 bg-volt-400 transition-transform duration-300 group-hover:scale-x-100"
              />
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-2.5 xl:flex">
          <a
            href={contact.linkedin}
            target={getLinkTarget(contact.linkedin)}
            rel="noopener noreferrer"
            aria-label="Connect on LinkedIn"
            className="grid h-10 w-10 place-items-center rounded-full border border-white/12 text-mist transition-all duration-300 hover:-translate-y-0.5 hover:border-[#0A66C2]/60 hover:text-[#4d9fff]"
          >
            <IconLinkedIn className="h-4.5 w-4.5" />
          </a>
          <ButtonPrimary href={whatsappUrl} className="px-5 py-2.5">
            <IconWhatsApp className="h-4 w-4" />
            WhatsApp me
          </ButtonPrimary>
        </div>

        <button
          type="button"
          className="grid h-11 w-11 place-items-center rounded-full border border-white/10 bg-white/[0.03] text-cream transition-colors hover:border-volt-400/40 xl:hidden"
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <IconX className="h-5 w-5" /> : <IconMenu className="h-5 w-5" />}
        </button>
      </div>

      {/* Mobile panel */}
      <div
        id="mobile-menu"
        className={cn(
          "overflow-hidden transition-[max-height,opacity] duration-500 ease-out xl:hidden",
          open ? "max-h-[520px] opacity-100" : "max-h-0 opacity-0"
        )}
      >
        <nav aria-label="Mobile" className="glass mx-4 mt-3 rounded-2xl border border-white/10 p-4 shadow-lift">
          <ul className="flex flex-col">
            {links.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="flex items-center justify-between rounded-xl px-4 py-3.5 text-[15px] font-semibold text-cream transition-colors hover:bg-white/[0.05]"
                >
                  {l.label}
                  <IconArrowRight className="h-4 w-4 text-mist-2" />
                </a>
              </li>
            ))}
          </ul>
          <div className="mt-3 flex gap-2.5">
            <a
              href={contact.linkedin}
              target={getLinkTarget(contact.linkedin)}
              rel="noopener noreferrer"
              onClick={() => setOpen(false)}
              className="flex flex-1 items-center justify-center gap-2 rounded-full border border-white/12 py-3.5 font-display text-sm font-semibold text-cream"
            >
              <IconLinkedIn className="h-4 w-4 text-[#4d9fff]" />
              LinkedIn
            </a>
            <a
              href={whatsappUrl}
              target={getLinkTarget(whatsappUrl)}
              rel="noopener noreferrer"
              onClick={() => setOpen(false)}
              className="btn-sheen flex flex-1 items-center justify-center gap-2 rounded-full bg-volt-400 py-3.5 font-display text-sm font-semibold text-ink-950"
            >
              <IconWhatsApp className="h-4 w-4" />
              WhatsApp
            </a>
          </div>
        </nav>
      </div>
    </header>
  );
}
